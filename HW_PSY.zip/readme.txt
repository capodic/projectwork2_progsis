Homework per Programmazione di sistema, Descrizione della soluzione
.
Vengono testate funzioni di get e put bloccanti e non di messaggi di testo anche se la struttura e' generica.
Utilizzato framework CUnit in cui e' stata creata una Suite con 5 test principali per il test dei casi piu' significativi
Il buffer e' strutturato come array circolare con testa (inizio), coda (fine), numero elementi e size e un puntatore ad array dinamico ai messaggi, la cui dimensione e' definita per ciascun test (passata come parametro alla funzione create_buffer()).
Per l'accesso al buffer in modo sincronizzato da parte dei thread concorrenti sono usate 2 variable condition (NON_PIENO e NON_VUOTO) ed un mutex. Quando il buffer da pieno passa a non pieno la get segnala evento NON_PIENO per risvegliare eventuali put bloccate, e quando da vuoto passa a non vuoto la put segnala evento NON_VUOTO per svegliare eventuali get bloccate.
Per compilare:
- gcc HW_PSY.c -o HW_PSY -l pthread -lcunit
Per eseguire:
- ./HW_PSY
Esempio di output del programma in output.txt.

Testato in Ubuntu 20.04 LTS e ggc 9.3.0 (Ubuntu 9.3.0-10ubuntu2) sotto WSL2 di Windows 10.
