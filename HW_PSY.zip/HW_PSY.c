#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h> /* include per sleep() */
#include "CUnit/CUnit.h"
#include "CUnit/Basic.h"

#pragma warning(disable : 4996)

#define BUFFER_ERROR (msg_t *) NULL
//#define N 1 /* N dimensione del buffer dei messaggi*/
//#define MAX_ELEM N
//#define C 0 /* C numero dei thread CONSUMATORI */
//#define P 1 /* P numero dei thread PRODUTTORI */
//#define S 0 /* S numero degli slot occupati del buffer allo stato iniziale */

#define CUNIT_TEST 1

pthread_cond_t vc_non_pieno = PTHREAD_COND_INITIALIZER;; /*var condition su buffer pieno*/
pthread_cond_t vc_non_vuoto = PTHREAD_COND_INITIALIZER;; /*var condition su buffer vuoto*/
pthread_mutex_t mutex_buffer = PTHREAD_MUTEX_INITIALIZER; /*mutex per accesso R/W a buffer */
int consumatore_in_attesa =0; /* 0 = nessuno (false), >=1 in attesa (true) acceduto tramite mutex_buffer, nella stessa sezione critica */
int produttore_in_attesa = 0;

typedef struct msg {
	void* content; // generico contenuto del messaggio
	struct msg * (*msg_init)(void*); // creazione msg
	void(*msg_destroy)(struct msg *); // deallocazione msg
	struct msg * (*msg_copy)(struct msg *); // creazione/copia msg
} msg_t;

typedef struct buffer {
	int testa, coda, n_elem, size;
	msg_t** messaggi; // puntatore ad array di strutture di messaggi di dimensione stabilita dinamicamente
} buffer_t;

/* argomento da passare alle funzioni wrapper per put_xxx e get_xxx*/
struct arg_struct {
	buffer_t* arg1;
	msg_t* arg2;
};

msg_t* msg_copy_string(msg_t* msg) {
	return msg->msg_init(msg->content);
}

void msg_destroy_string(msg_t* msg) {
	//copia privata
	free(msg); // free struct
}

msg_t* msg_init_string(void* content) {
	//viene creata una copia "privata" della stringa
	msg_t* new_msg = (msg_t*)malloc(sizeof(msg_t));
	char* string = (char*)content;
	char* new_content = (char*)malloc(strlen(string) + 1); // +1 per \0 finale
	strcpy(new_content, string);
	new_msg->content = new_content;
	new_msg->msg_init = msg_init_string;
	new_msg->msg_destroy = msg_destroy_string;
	new_msg->msg_copy = msg_copy_string;
	return new_msg;
}

/* stampa contenuto buffer */
void stampa_buffer(buffer_t* b) {
	int MAX_ELEM = b->size;
	if (b->n_elem == 0) {
		printf("stampa_buffer() - Buffer E' VUOTO \n");
		return;
	}
	printf("stampa_buffer() - Buffer contiene %d elementi (testa:%d, coda:%d)\n", b->n_elem, b->testa, b->coda);
	for (int i = 0; i < b->n_elem; i++) {
		if (b->testa == -1)
			printf("\tElemento %d: %s\n", i, (char*)b->messaggi[(b->coda + i) % MAX_ELEM]->content);
		else
			printf("\tElemento %d: %s\n", i, (char*)b->messaggi[(b->testa + i) % MAX_ELEM]->content);
	}
}

/* alloca memoria per buffer e per coda di messaggi di dimensione passata per parametro size e ritorna puntatore */
buffer_t* create_buffer(int size) {
	buffer_t* b;
	b = (buffer_t *)malloc(sizeof(buffer_t));
	b->testa = 0;
	b->coda = 0;
	b->n_elem = 0;
	b->size = size;
	b->messaggi = malloc(size * sizeof(msg_t));
	return b;
}

/* dealloca memoria per buffer e messaggi tramite puntatore */
int destroy_buffer(buffer_t* b) {
	free(b->messaggi);
	free(b);
	return 0;
}


// prende in ingresso riferimento a buffer e a msg ed involca la funzione di put per inserire il ptr al msg in buffer, 
// ritorna il ptr al msg inserito o NULL in caso di errore
msg_t* put(buffer_t* b, msg_t* msg) {
	int MAX_ELEM = b->size;
	if (b->n_elem == MAX_ELEM) {
		printf("Errore put(): Buffer Pieno!!");
		return BUFFER_ERROR;
	}
	else {
		b->messaggi[b->coda] = msg;
		if (b->testa == -1)
			b->testa = b->coda;
		b->coda = (b->coda + 1) % MAX_ELEM;

		b->n_elem++;
	}
	return msg;
}

/* put_bloccante() */
/* entra nella sezione critica e poi controlla buffer pieno tramite mutex */
/* testa la var condition buffer pieno */
/* se buffer pieno aspetta sulla var cond vc_non_pieno */
/* altrimenti esegue la put */
msg_t* put_bloccante(buffer_t* b, msg_t* msg /* void *p // creato wrapper */) {
	/* per avere la signature come richiesto definire funzione wrapper che prende void* perche' non funziona con cast direttamente !! */
	const char *fncName = "put_bloccante()";
	int res;
	int ciclo_wait = 0;
	int MAX_ELEM = b->size;

	/* creato wrapper
	struct arg_struct * as_ptr = (struct arg_struct*) p;
	buffer_t* b = as_ptr->arg1;
	msg_t* msg = as_ptr->arg2; */

	//printf("pointer b (args1) %p\n", b); /*b is not nil !!*/
	//printf("pointer msg (arg2) %p\n", msg); /*msg is nil !!*/

	pthread_t handle_t = pthread_self();
	/* test msg non nullo */
	if (!msg || !msg->content) {
		printf("ERRORE parametro msg del thread %s - Handle: %lu\n", fncName, handle_t);
		printf("%p\n", b); /*b is not nil !!*/
		printf("%p\n", msg); /*msg is nil !!*/
		/*printf("%s", (char*) msg->content);*/
		return BUFFER_ERROR;
	}

	printf("Avvio thread %s - Handle: %lu\n", fncName, handle_t);
	
	pthread_mutex_lock(&mutex_buffer);	
	printf("Thread %s  %lu nella sezione critica.\n", fncName, handle_t);
	stampa_buffer(b);
	
	//printf("********Elementi array msg di buffer: %d\n", max_elem);

	while (b->n_elem == MAX_ELEM) {
		if (ciclo_wait == 0) { // evita incremento nei casi di risveglio spuri..
			ciclo_wait = 1;
			produttore_in_attesa++;
		}
		printf("Thread %s %lu si SOSPENDE sulla condition variable NON_PIENO. N. Prod. in attesa: %d \n", fncName, handle_t, produttore_in_attesa);
		pthread_cond_wait(&vc_non_pieno, &mutex_buffer); /* rilascia il mutex mutex_buffer e attende il cambio di stato della vc vc_non_vuoto */
		/* quando la wait ritorna bisogna ricontrllare la condizione, quindi mettere in ciclo while...vedi  pag.32 http://www.ce.uniroma2.it/courses/sdcc1617/lucidi/Pthreads.pdf */
	}
	if (ciclo_wait == 1) {
		produttore_in_attesa--;
		printf("Thread %s %lu si RISVEGLIA sulla condition variable NON_PIENO. N. Prod. in attesa: %d \n", fncName, handle_t, produttore_in_attesa);
	}

	/* qui il thread e' risvegliato o cmq ha testato per buffer non pieno, ha il lock sul mutex*/
	printf("Thread %s %lu effettua inserimento msg: %s\n", fncName, handle_t, (char*) msg->content);
	b->messaggi[b->coda] = msg;
	if (b->testa == -1)
		b->testa = b->coda;
	b->coda = (b->coda + 1) % MAX_ELEM;
	b->n_elem++;
	printf("Thread %s %lu conta n_elem: %d\n", fncName, handle_t, b->n_elem);
	stampa_buffer(b);
	printf("Thread %s %lu segnala buffer non vuoto....\n", fncName, handle_t);
	/* segnala buffer non vuoto per svegliare eventuali thread in get_bloccante() */
	/* il mutex e' gia' preso prima di modificare la condizione per il signal... */
	res = pthread_cond_signal(&vc_non_vuoto); /* res da controllare, !=0 errore */
	printf("Thread %s %lu in procinto di uscire dalla sezione critica.\n", fncName, handle_t);
	res = pthread_mutex_unlock(&mutex_buffer);  /* res da controllare, !=0 errore */
	printf("Thread %s %lu in procinto di terminare.\n", fncName, handle_t);
	return msg;
}

void* wrapper_put_bloccante(void* p) {
	struct arg_struct * as_ptr = (struct arg_struct*) p;
	buffer_t* b = as_ptr->arg1;
	msg_t* msg = as_ptr->arg2;
	return(put_bloccante(b, msg));
}

/* funz che inserisce messaggio msg nel buffer b se c'e' spazio nel buffer, altrimenti ritorna BUFFER_ERROR */
msg_t* put_non_bloccante(buffer_t* b, msg_t* msg) {
	/* prende mutex */
	/* controlla se non_pieno, allora effettua inserimento nel buffer */
	/* altrimenti ritorna BUFFER_ERROR */
	int res;
	const char* fncName = "put_non_bloccante()";
	int MAX_ELEM = b->size;

	pthread_t handle_t = pthread_self();
	/* test msg non nullo */
	if (!msg || !msg->content) {
		printf("ERRORE parametro msg del thread %s - Handle: %lu\n", fncName, handle_t);
		printf("%p\n", b); /*b is not nil !!*/
		printf("%p\n", msg); /*msg is nil !!*/
		/*printf("%s", (char*) msg->content);*/
		return BUFFER_ERROR;
	}
	printf("\nAvvio thread %s - Handle: %lu\n", fncName, handle_t);
	int res_lock;
	/*pthread_mutex_trylock(&mutex_buffer);
	if (res_lock == EBUSY) {
		printf("BUFFER EBUSY del thread put_non_bloccante() - mutex mutex_buffer BUSY - Handle: %lu\n", handle_t);
		return BUFFER_ERROR;
	}*/
	pthread_mutex_lock(&mutex_buffer);
	/* qui abbiamo il mutex possiamo modificare buffer b*/
	printf("Thread %s %lu nella sezione critica.\n", fncName, handle_t);
	stampa_buffer(b);
	if (b->n_elem == MAX_ELEM) {
		printf("Thread %s %lu ritorna BUFFER_ERROR sulla condition variable NON_PIENO.\n", fncName, handle_t);
		pthread_mutex_unlock(&mutex_buffer);
		return BUFFER_ERROR; /* rilascia il mutex mutex_buffer e attende il cambio di stato della vc vc_non_pieno*/
	}
	/* qui il thread ha testato per buffer non pieno, ed ha il lock sul mutex*/
	printf("Thread %s %lu effettua put_non_bloccante() su buffer non pieno. Put msg: %s\n", fncName, handle_t, (char*) msg->content);
	b->messaggi[b->coda] = msg;
	if (b->testa == -1)
		b->testa = b->coda;
	b->coda = (b->coda + 1) % MAX_ELEM;
	b->n_elem++;
	stampa_buffer(b);

	stampa_buffer(b);
	printf("Thread %s %lu segnala buffer non vuoto....\n", fncName, handle_t);
	/* segnala buffer non vuoto per svegliare eventuali thread in get_bloccante() */
	/* il mutex e' gia' preso prima di modificare la condizione per il signal... */
	res = pthread_cond_signal(&vc_non_vuoto); /* res da controllare, !=0 errore */
	printf("Thread %s %lu in procinto di uscire dalla sezione critica.\n", fncName, handle_t);
	res = pthread_mutex_unlock(&mutex_buffer);  /* res da controllare, !=0 errore */

	printf("Thread %s %lu in procinto di terminare.\n", fncName, handle_t);
	return msg;
}

void* wrapper_put_non_bloccante(void* p) {
	struct arg_struct * as_ptr = (struct arg_struct*) p;
	buffer_t* b = as_ptr->arg1;
	msg_t* msg = as_ptr->arg2;
	return(put_non_bloccante(b, msg));
}

// prende in ingresso riferimento a buffer e ne estrae il ptr al messaggio in testa (inizio buffer)
// se volessi resttuire il msg e non il suo ptr dovrei copiare il messaggio e liberare quello del buffer..
msg_t* get(buffer_t* b) {
	int MAX_ELEM = b->size;
	msg_t* result;
	if (b->n_elem == 0) {
		printf("Errore get(): Buffer Vuoto!!");
		return BUFFER_ERROR;
	}
	else {
		result = b->messaggi[b->testa];
		if (MAX_ELEM > 1)
			b->testa = (b->testa + 1) % MAX_ELEM;
		else
			b->testa = -1;
		b->n_elem--;
	}
	return result;
}

msg_t* get_bloccante(buffer_t* b /* void* arg // creato wrapper*/) {
	int res;
	int ciclo_wait = 0;
	int MAX_ELEM = b->size;
	// buffer_t* b = (buffer_t *)arg; // creato wrapper
	msg_t* result_msg;
	pthread_t handle_t = pthread_self();
	const char * fncName = "get_bloccante()";

	printf("Avvio thread %s - Handle: %lu\n", fncName, handle_t);
	pthread_mutex_lock(&mutex_buffer);
	printf("Thread %s %lu nella sezione critica.\n", fncName, handle_t);
	stampa_buffer(b);
	while (b->n_elem == 0) {
		if (ciclo_wait == 0) { // evita incremento nei casi di risveglio spuri..
			ciclo_wait = 1;
			consumatore_in_attesa++;
		}
		printf("Thread %s %lu si SOSPENDE sulla condition variable NON_VUOTO. N. Cons in attesa: %d \n", fncName, handle_t, consumatore_in_attesa);
		pthread_cond_wait(&vc_non_vuoto, &mutex_buffer); /* rilascia il mutex mutex_buffer e attende il cambio di stato della vc vc_non_vuoto */
		/* quando la wait ritorna bisogna ricontrllare la condizione, quindi mettere in ciclo while...vedi  pag.32 http://www.ce.uniroma2.it/courses/sdcc1617/lucidi/Pthreads.pdf */
		/* occorre che la put faccia la segnalazione...ok inserita*/
	}
	if (ciclo_wait == 1) {
		consumatore_in_attesa--;
		printf("Thread %s %lu si RISVEGLIA sulla condition variable NON_VUOTO. N. Cons in attesa: %d \n", fncName, handle_t, consumatore_in_attesa);
	}
	/* qui il thread e' risvegliato o cmq ha testato per buffer non pieno, ha il lock sul mutex*/
	
	printf("Thread %s %lu estrae msg dal buffer...N. Cons in attesa %d: \n", fncName, handle_t, consumatore_in_attesa);

	result_msg = b->messaggi[b->testa];
	if (MAX_ELEM > 1)
		b->testa = (b->testa + 1) % MAX_ELEM;
	else
		b->testa = -1;
	b->n_elem--;

	printf("Thread %s %lu in procinto di uscire dalla sezione critica.\n", fncName, handle_t);
	stampa_buffer(b);

	/* segnala buffer non pieno per svegliare eventuali thread in put_bloccante() */
	/* mutex gia' posseduto prima di modificare la condizione per il signal... */
	printf("Thread %s %lu segnala buffer NON PIENO....\n", fncName, handle_t);
	res = pthread_cond_signal(&vc_non_pieno); /* res da controllare, !=0 errore */
	res = pthread_mutex_unlock(&mutex_buffer); /* res da controllare, !=0 errore */
	printf("Thread %s %lu in procinto di terminare.\n", fncName, handle_t);
	printf("Messaggio estratto da %s %lu thread CONSUMATORE = %s \n", fncName, handle_t, (char*) result_msg->content);
	return result_msg;
}

void* wrapper_get_bloccante(void* p) {
	buffer_t* b = (buffer_t *)p;
	return(get_bloccante(b));
}

msg_t* get_non_bloccante(buffer_t* b /* void* arg // creato wrapper*/) {
	/* deve controllare se buffer vuoto, allora ritorna subito BUFFER_ERROR */
	/* devo fare un controllo sulla vc senza bloccare il thread in attesa...*/
	int res;
	int MAX_ELEM = b->size;
	// buffer_t* b = (buffer_t *)arg; // creato wrapper
	msg_t* result_msg;
	pthread_t handle_t = pthread_self();

	printf("Avvio thread get_non_bloccante() - Handle: %lu\n", handle_t);
	pthread_mutex_lock(&mutex_buffer);
	printf("Thread get_non_bloccante() nella sezione critica.\n");
	stampa_buffer(b);
	if (b->n_elem == 0) { /* buffer vuoto */
		printf("Thread %lu trovato buffer VUOTO...ritorna BUFFER_ERROR !\n", handle_t);
		pthread_mutex_unlock(&mutex_buffer);
		return BUFFER_ERROR;
	}
	/* qui il thread ha testato per buffer non vuoto, ha il lock sul mutex puo' procedere con la get()*/
	
	result_msg = b->messaggi[b->testa];
	if (MAX_ELEM > 1)
		b->testa = (b->testa + 1) % MAX_ELEM;
	else
		b->testa = -1;
	b->n_elem--;

	printf("Thread %lu in procinto di uscire dalla sezione critica.\n", handle_t);
	stampa_buffer(b);
	/* segnala buffer non pieno per svegliare eventuali thread in put_bloccante() */
	/* mutex gia' posseduto prima di modificare la condizione per il signal... */
	printf("Thread %lu segnala buffer non pieno....\n", handle_t);
	res = pthread_cond_signal(&vc_non_pieno); /* res da controllare, !=0 errore */
	res = pthread_mutex_unlock(&mutex_buffer); /* res da controllare, !=0 errore */
	printf("Thread %lu in procinto di terminare.\n", handle_t);
	printf("Meggaggio get_non_bloccante() thread CONSUMATORE (handle id=%lu) = %s \n", handle_t, (char*)result_msg->content);
	return result_msg;
}

void* wrapper_get_non_bloccante(void* p) {
	buffer_t* b = (buffer_t *)p;
	return(get_non_bloccante(b));
}

//struct arg_struct *args[P];
//msg_t* messaggio;
//buffer_t b;

/* The suite initialization function.
 * inizializza buffer messaggi.
 * Returns zero on success, non-zero otherwise.
 */
/* nessuna inizializzazione */
int init_suite1(void) {
	if (NULL) {
		return -1;
	}
	else {
		return 0;
	}
}

/* The suite cleanup function.
 * Pulisce buffer messaggi
 * Returns zero on success, non-zero otherwise.
 */
 /* nessuna cleanup */
int clean_suite1(void)
{
	if (NULL) {
		return -1;
	}
	else {
		return 0;
	}
}

/* 
 * Test di put_non_bloccante() con buffer inizialmente pieno
 */
void testT1(void)
{
	/* SETUP: 
	 * crea buffer pieno di dim unitaria con msg in coda EXPECTED_MSG
	 * la dim del bufer e' 1
	 */

	msg_t* messaggio_exp = msg_init_string((void*) "Messaggio EXPECTED_MSG");
	msg_t* msg = msg_init_string((void*) "Messaggio MSG");
	buffer_t* buffer_pieno = create_buffer(1); 	// inizializzo l'array circolare di puntatori a msg
	//buffer_pieno->messaggi[0] = messaggio_exp;
	put(buffer_pieno, messaggio_exp);
	msg_t* res;

	/* sezione sostituita da put_non_bloccante
	res = put(buffer_pieno, messaggio_exp);
	if (res == BUFFER_ERROR || strcmp((char*) messaggio_exp->content, (char*) msg->content)==0) {
		CU_FAIL("testT1() FAIL due to wrong buffer initilization");
		free(buffer_pieno);
		return;
	};*/

	/* SOLLECITAZIONE: 
	 * invoca put_non_bloccante(MSG) con MSG != EXPECTED_MSG su buffer pieno
	 */

	res = put_non_bloccante((buffer_t*)buffer_pieno, msg); // cast buffer_t* per soppressione warning! buffer_t ha capacit' 1 solo messaggio!

	/* VERIFICA:
	 * verifica che put_non_bloccante() restituisca BUFFER_ERROR e buffer contiene EXPECTED_MSG
	 */
	CU_ASSERT_EQUAL(res, BUFFER_ERROR);
	printf("messaggio_exp: %s || messaggio in buffer: %s \n", (char*)messaggio_exp->content, (char*)buffer_pieno->messaggi[0]->content);
	CU_ASSERT_STRING_EQUAL((char*)messaggio_exp->content, (char*)buffer_pieno->messaggi[0]->content);
	destroy_buffer(buffer_pieno);
}

/* Test di get_bloccante() con buffer inizialmente vuoto
 * la dim del bufer e' settata a 1
 */
void testT2(void)
{

	/* SETUP:
	 * crea buffer vuoto di dim unitaria, inizialmente vuoto
	 * crea e avvia consumatore che deve bloccarsi su buffer_vuoto-> ci vuole un thread !!!
	 */
	
	buffer_t* buffer_vuoto = create_buffer(1);; 	// inizializzo l'array circolare di puntatori a msg
	pthread_t consum_thread_id;

	// avvio thread consumatore per get_bloccante (UNIX)
	printf("\nAvvio thread CONSUMATORE per get_bloccante() ...  ");
	int consum = pthread_create(&consum_thread_id, NULL, (void*) wrapper_get_bloccante, (void*) buffer_vuoto);
	/* 0 is success, !=0 is ERROR */
	if (consum != 0)			/* could not create thread */
	{
		printf("\n pthread_create() ERROR: return code from pthread_create is %d \n", consum);
		/* si dovrebbe rilasciare tutta la memoria allocata con malloc()...*/
		/*  ... free di args_cons ecc.. */
		destroy_buffer(buffer_vuoto);
		exit(1);
	} else
		printf("avviato - Handle %lu...\n", consum_thread_id);

	/* SOLLECITAZIONE:
	 * verifica che il consumatore e' bloccato..
	 * non esiste una funzione per vedere se un thread e' bloccato su wait in pthread .. https://pubs.opengroup.org/onlinepubs/007908799/xsh/pthread.h.html 
	 * trylock() o pthread_cond_timedwait() verifica che c'e' lock su buffer no chi sia il thread in attesa..
	 * ... metto una var globale per la verifica usando il mutex del buffer per accesso esclusivo e verifico tramite stampa a video da parte del consumatore...
	 * sblocca get depositando con put_xxx_bloccante GO_MSG in buffer_vuoto (e triggerndo lo sblocco per far consumare la get_bloccante()
	 */
	printf("Attesa 2 secondi per avviare thread consumatore get_bloccante()... \n");
	sleep(2); /* va in sleep per dare tempo di avviare il thread secondario del consumatore... altrimenti semaforo per vedere quando e' avviato...*/
		
	pthread_mutex_lock(&mutex_buffer);
	printf("Verifica se thread consumatore get_bloccante() e' in attesa... (%d = %d) ", 1, consumatore_in_attesa);
	if (consumatore_in_attesa >0)
		printf("passed\n");
	else
		printf("failed\n");
	CU_ASSERT_EQUAL(1, consumatore_in_attesa);
	pthread_mutex_unlock(&mutex_buffer);

	/* effettuo put_non_bloccante()..tanto il buffer_vuoto e' vuoto... */
	msg_t* GO_MSG = msg_init_string((void*) "Messaggio GO_MSG");
	/* creato wrapper */
	//args = malloc(sizeof(struct arg_struct)); /* ogni ciclo deve generare un'area di memoria diversa*/
	//args->arg1 = buffer_vuoto;
	//args->arg2 = GO_MSG;
	//put_bloccante((void*) args); 

	/* put_bloccante non eseguita in thread..main thread bloccato fino a ritorno della funzione...*/
	put_bloccante(buffer_vuoto, GO_MSG); // put_non_bloccante() deve funzionare allo stesso modo su buffer vuoto

	/* VERIFICA:
	 * verifica che get_bloccante() restituisca GO_MSG e che buffer_vuoto sia vuoto 
	 * un thread non torna nulla -> vedo stampa a video..altrim dovrei usare una struttura globale sulla quale scrivere e fare assert e varrebbe solo per questo test
	 * non farebbe parte della soluzione finale...lascio la stampa a video
	 */
	/* QUA DEVE FARE JOIN IN ATTESA CHE I THREAD TERMINANO*/
	void* res;
	printf("\n Attesa JOIN thread CONSUMATORE (handle id=%lu) ...\n", consum_thread_id);
	pthread_join(consum_thread_id, &res);
	CU_ASSERT_EQUAL(0, buffer_vuoto->n_elem );
	/* creato wrapper */ //free(args);
	destroy_buffer(buffer_vuoto);
}

void chcek_res(int res) {  // funziona da chiamare per test del risultato delle funzioni della lib pthread.h
	if (res != 0) {
		fputs("pthread_function() error\n", stderr);
		exit(EXIT_FAILURE);
	}
}

/*
 * Test di get_bloccante() con buffer unitario inizialmente pieno e consumatori concorrenti
 */
void testT3(void)
{
	/* SETUP:
	 * crea buffer pieno di dim unitaria con msg in coda 
	 * la dim del bufer e' 1
	 */
	const int C = 3;  // num di thread consumatori da avviare

	buffer_t* buffer_pieno = create_buffer(1); 	// inizializzo l'array circolare di puntatori a msg
	buffer_pieno->messaggi[0] = msg_init_string((void*) "Messaggio #1");
	msg_t* res;
	pthread_t consum_thread_id[C];

	/* SOLLECITAZIONE:
	 * crea C consumatori concorrenti che invocano get_bloccante(MSG), con C > 1 che tentano di prelevare l'unico messaggio nel buffer..
	 * il primo che riesce ad acquisire il mutex stampa il msg a video...gli altri rimangono in attesa bloccati...
	 * invoca  con MSG != EXPECTED_MSG su buffer pieno
	 */

	for (int i = 0; i < C; i++) {
		// avvio thread consumatore per get_bloccante (UNIX)
		printf("\nAvvio thread CONSUMATORE per get_bloccante()  n.: %d ... " , i);
		int consum = pthread_create(&consum_thread_id[i], NULL, (void*)wrapper_get_bloccante, (void*)buffer_pieno);
		/* 0 is success, !=0 is ERROR */
		if (consum != 0)			/* could not create thread */
		{
			printf("\n pthread_create() ERROR: return code from pthread_create is %d \n", consum);
			/* si dovrebbe rilasciare tutta la memoria allocata con malloc()...*/
			/*  ... free di args_cons ecc.. */
			destroy_buffer(buffer_pieno);
			exit(1);
		}
		else
			printf("avviato - Handle %lu...\n", consum_thread_id[i]);
	}

	/* VERIFICA:
	 * verifica che la get_bloccante() che per prima acquisisce il lock stampa il msg iniziale, che il buffer dopo sia vuoto e che l'altro thread risulti bloccato
	 */

	printf("Attesa 2 secondi per avviare i thread consumatore get_bloccante()... \n");
	sleep(2); /* va in sleep per dare tempo di avviare il thread secondario del consumatore... altrimenti semaforo per vedere quando e' avviato...*/

	pthread_mutex_lock(&mutex_buffer);
	printf("Verifica se almeno 1 thread consumatore get_bloccante() e' in attesa... (%d >0) ", consumatore_in_attesa);
	if (consumatore_in_attesa > 0)
		printf("passed\n");
	else
		printf("failed\n");
	CU_ASSERT_TRUE(consumatore_in_attesa);
	pthread_mutex_unlock(&mutex_buffer);

	/* sblocco dei thread bloccati ...*/
	printf("*******Sblocco dei thread bloccati..\n");
	char msg[80];
	for (int i = 0; i < C; i++) {
		buffer_pieno->testa = 0;
		buffer_pieno->coda = 0;
		buffer_pieno->n_elem = 1;
		sprintf(msg, "Messaggio #%i", i+2); // #1 e' gia' stampo usato, parto da 2..
		buffer_pieno->messaggi[0] = msg_init_string((void*) msg);
		pthread_cond_signal(&vc_non_vuoto);
		sleep(2); // dovrebbe estrarre anche il secondo msg..
	}
	destroy_buffer(buffer_pieno);

	/* esco senza terminare i thread in attesa, che verranno terminati con il processo*/
	return;
}

/*
 * Test di put_bloccante() con buffer unitario inizialmente vuoto e produttori concorrenti
 */
void testT4(void)
{
	/* SETUP:
	 * crea buffer vuoto di dim unitaria
	 * la dim del bufer e' 1
	 */
	const int P = 3;  // num di thread produttori da avviare

	/* inizializo buffer */
	msg_t* res;
	pthread_t prod_thread_id[P];
	struct arg_struct *args[P];
	msg_t **messaggi; /*array di stringhe*/
//	msg_t* messaggio;

	/* SOLLECITAZIONE:
	 * crea C consumatori concorrenti che invocano put_bloccante(MSG), con P > 1 che tentano di inserire un messaggio nel buffer..
	 * il primo che riesce ad acquisire il mutex inserisce in coda e stampa il msg a video...gli altri rimangono in attesa bloccati...
	 */

	buffer_t* buffer_vuoto = create_buffer(1); 	// inizializzo l'array circolare di puntatori a msg

	/* genero array di args da passare ai thread, i msg sono strutture diverse e vengono allocate e liberate alla fine */
	messaggi = (msg_t**) malloc(P*sizeof(msg_t*)); /*alloco P elementi da 80 caratteri*/
	char msg[80];
	for (int i = 0; i < P; i++) {
		args[i] = malloc(sizeof(struct arg_struct)); /* ogni ciclo deve generare un'area di memoria diversa*/
		args[i]->arg1 = buffer_vuoto;
		sprintf(msg, "Messaggio per put bloccante #%d", i);
		//args[i]->arg2 = msg_init_string((void*)msg);
		messaggi[i] = (msg_t*) malloc(sizeof(msg_t));
		messaggi[i] = msg_init_string((void*)msg);
		args[i]->arg2 = messaggi[i];
		stampa_buffer(buffer_vuoto);
		printf("args->args2: %s\n", (char*)args[i]->arg2->content);

		// avvio thread consumatore per get_bloccante (UNIX)
		printf("\nAvvio thread PRODUTTORE per put_bloccante()  n.: %d ...  \n", i);
		int prod = pthread_create(&prod_thread_id[i], NULL, (void*)wrapper_put_bloccante, (void*)args[i]);
		/* 0 is success, !=0 is ERROR */
		if (prod != 0)			/* could not create thread */
		{
			printf("\n pthread_create() ERROR: return code from pthread_create is %d \n", prod);
			/* si dovrebbe rilasciare tutta la memoria allocata con malloc()...*/
			/*  ... free di args_cons ecc.. */
			destroy_buffer(buffer_vuoto);
			exit(1);
		}
		else
			printf("tread PRODUTTORE n.: %d avviato - Handle %lu...\n", i, prod_thread_id[i]);
	}

	/* VERIFICA:
	 * verifica che la get_bloccante() che per prima acquisisce il lock stampa il msg iniziale, che il buffer dopo sia vuoto e che l'altro thread risulti bloccato
	 */

	printf("Attesa 2 secondi per avviare i thread produttore put_bloccante()... \n");
	sleep(2); /* va in sleep per dare tempo di avviare il thread secondario del produttore... altrimenti semaforo per vedere quando e' avviato...*/

	pthread_mutex_lock(&mutex_buffer);
	printf(">>>>>>Verifica se almeno 1 thread produttore put_bloccante() e' in attesa... (%d >0) ", produttore_in_attesa);
	if (produttore_in_attesa > 0)
		printf("passed\n");
	else
		printf("failed\n");
	CU_ASSERT_TRUE(produttore_in_attesa);
	pthread_mutex_unlock(&mutex_buffer);

	/* sblocco dei thread bloccati ...*/
	printf("*******Sblocco dei thread bloccati..\n");
	for (int i = 0; i < P; i++) {
		printf("Estraggo msg dalla coda: %s\n", (char *) get_non_bloccante(buffer_vuoto)->content); 
		/* con lo sleep i successivi get_non_bloccanti dovrebbero trovare sempre messaggi nel buffer*/
		sleep(2); // dovrebbe estrarre anche il secondo msg..
	}

	/* free var allocate*/
	printf("free() var allocate...\n");
	for (int i = 0; i < P; i++) {
		free(messaggi[i]);
		free(args[i]);
	}
	free(messaggi);
	destroy_buffer(buffer_vuoto);

	/* esco senza terminare i thread in attesa, che verranno terminati con il processo*/
	return;
}

/*
 * Test di thread concorrenti di put_bloccante() e get_bloccante() con buffer N-ario inizialmente vuoto 
 */
void testT5(void)
{
	/* SETUP:
	 * crea buffer vuoto di dim unitaria con msg in coda
	 * la dim del bufer e' 1
	 */
	const int P = 3;  // num di thread produttori da avviare
	const int C = 3;  // num di thread produttori da avviare
	const int N = 2;  // num di thread produttori da avviare

	/* inizializo buffer */
	buffer_t* buffer_vuoto=create_buffer(N); 	// inizializzo l'array circolare di puntatori a msg

	msg_t* res;
	pthread_t prod_thread_id[P];
	struct arg_struct *args[P];
	msg_t **messaggi; /*array di stringhe*/
//	msg_t* messaggio;

	/* SOLLECITAZIONE:	
	 * crea P (P>1) produttori concorrenti che invocano put_bloccante() per inserire un messaggio presente nel buffer di dimensione P con P<C,
	 * poi crea P (P=C) consumatori concorrenti che invocano get_bloccante(MSG) tentando di estrarre un messaggio nel buffer..
	 */

	/* genero array di args da passare ai thread, i msg sono strutture diverse e vengono allocate e liberate alla fine */
	messaggi = (msg_t**)malloc(P * sizeof(msg_t*)); /*alloco P elementi da 80 caratteri*/
	char msg[80];
	for (int i = 0; i < P; i++) {
		args[i] = malloc(sizeof(struct arg_struct)); /* ogni ciclo deve generare un'area di memoria diversa*/
		args[i]->arg1 = buffer_vuoto;
		sprintf(msg, "Messaggio per put bloccante #%d", i);
		//args[i]->arg2 = msg_init_string((void*)msg);
		messaggi[i] = (msg_t*)malloc(sizeof(msg_t));
		messaggi[i] = msg_init_string((void*)msg);
		args[i]->arg2 = messaggi[i];
		stampa_buffer(buffer_vuoto);
		//printf("args->args2: %s\n", (char*)args[i]->arg2->content);

		// avvio thread consumatore per get_bloccante (UNIX)
		printf("\nAvvio thread PRODUTTORE per put_bloccante()  n.: %d ...  \n", i);
		int prod = pthread_create(&prod_thread_id[i], NULL, (void*)wrapper_put_bloccante, (void*)args[i]);
		/* 0 is success, !=0 is ERROR */
		if (prod != 0)			/* could not create thread */
		{
			printf("\n pthread_create() ERROR: return code from pthread_create is %d \n", prod);
			/* si dovrebbe rilasciare tutta la memoria allocata con malloc()...*/
			/*  ... free di args_cons ecc.. */
			free(buffer_vuoto->messaggi);
			free(buffer_vuoto);
			exit(1);
		}
		else
			printf("tread PRODUTTORE n.: %d avviato - Handle %lu...\n", i, prod_thread_id[i]);
	}

	/* VERIFICA:
	 * verifica che la put_bloccante() crei produttori in attesa per P>N
	 */

	printf("Attesa 2 secondi per avviare i thread produttore put_bloccante()... \n");
	sleep(2); /* va in sleep per dare tempo di avviare il thread secondario del produttore... altrimenti semaforo per vedere quando e' avviato...*/

	pthread_mutex_lock(&mutex_buffer);
	printf(">>>>>>Verifica se almeno 1 thread produttore put_bloccante() e' in attesa... (%d >0) ", produttore_in_attesa);
	if (produttore_in_attesa > 0)
		printf("passed\n");
	else
		printf("failed\n");
	CU_ASSERT_TRUE(produttore_in_attesa);
	pthread_mutex_unlock(&mutex_buffer);

	/* sblocco dei thread bloccati ...*/
	printf("*******Sblocco dei thread bloccati..\n");
	for (int i = 0; i < C; i++) {
		// avvio thread consumatore per get_bloccante (UNIX)
		printf("\nAvvio thread CONSUMATORE per get_bloccante()  n.: %d ...  \n", i);
		int cons = pthread_create(&prod_thread_id[i], NULL, (void*)wrapper_get_bloccante, (void*)buffer_vuoto);
		/* 0 is success, !=0 is ERROR */
		if (cons != 0)			/* could not create thread */
		{
			printf("\n pthread_create() ERROR: return code from pthread_create is %d \n", cons);
			/* si dovrebbe rilasciare tutta la memoria allocata con malloc()...*/
			/*  ... free di args_cons ecc.. */
			exit(1);
		}
		else
			printf("tread CONSUMATORE n.: %d avviato - Handle %lu...\n", i, prod_thread_id[i]);

	}

	printf("Attesa 2 secondi per far terminare i thread cosnumatori get_bloccante()... \n");
	sleep(2); /* va in sleep per dare tempo di avviare il thread secondario del produttore... altrimenti semaforo per vedere quando e' avviato...*/

	pthread_mutex_lock(&mutex_buffer);
	printf(">>>>>>Verifica nessun thread e' in attesa, produttore (%d == 0) o consumatore (%d == 0) ...  ", produttore_in_attesa, consumatore_in_attesa);
	if (produttore_in_attesa == 0 && consumatore_in_attesa == 0)
		printf("passed\n");
	else
		printf("failed\n");
	CU_ASSERT_FALSE(produttore_in_attesa && consumatore_in_attesa);
	pthread_mutex_unlock(&mutex_buffer);

	/* free var allocate*/
	/*
	printf("free() var allocate...\n");
	for (int i = 0; i < P; i++) {
		free(messaggi[i]);
		free(args[i]);
	}
	free(messaggi);
	free(buffer_vuoto->messaggi);
	*/
	free(buffer_vuoto);

	/* esco senza terminare i thread in attesa, che verranno terminati con il processo*/
	return;
}

int main(int argc, char* argv[]) {

	CU_pSuite pSuite = NULL;

	/* initialize the CUnit test registry */
	if (CUE_SUCCESS != CU_initialize_registry())
		return CU_get_error();

	/* add a suite to the registry */
	pSuite = CU_add_suite("Suite_1", init_suite1, clean_suite1);
	if (NULL == pSuite) {
		CU_cleanup_registry();
		return CU_get_error();
	}

	/* add the tests to the suite */
	/* NOTE - ORDER IS IMPORTANT -  */
	if ((NULL == CU_add_test(pSuite, "***TestT1 di put_non_bloccante() con buffer unitario inizialmente pieno, 1 PRODUTTORE\n----------------------------------\n", testT1)) ||
		(NULL == CU_add_test(pSuite, "***TestT2 of get_bloccante() con buffer unitario inizialmente vuoto, 1 CONSUMATORE\n----------------------------------\n", testT2)) || 
		(NULL == CU_add_test(pSuite, "***TestT3 of get_bloccante() con buffer unitario inizialmente pieno, C>1 CONSUMATORI concorrenti\n----------------------------------\n", testT3)) ||
		(NULL == CU_add_test(pSuite, "***TestT4 di put_bloccante() con buffer unitario inizialmente vuoto, P>1 PRODUTTORI concorrenti\n----------------------------------\n", testT4)) ||
		(NULL == CU_add_test(pSuite, "***TestT5 di put_bloccante() e get_bloccante() con buffer N-ario inizialmente vuoto, con C>1 e P>1 concorrenti, N<P\n----------------------------------\n", testT5)))
	{
		CU_cleanup_registry();
		return CU_get_error();
	}

	/* Run all tests using the CUnit Basic interface */
	CU_basic_set_mode(CU_BRM_VERBOSE);
	CU_basic_run_tests();
	CU_cleanup_registry();

	printf("\nUscita e deallocazione risorse...\n");
	/* per evitare hanging della cond_destroy occorre sbloccare le VC..anche se si rischia di far chiamare la get su buffer vuoti o put su buffer pieni...*/
	pthread_cond_broadcast(&vc_non_pieno);
	pthread_cond_broadcast(&vc_non_vuoto);

	pthread_cond_destroy(&vc_non_pieno);
	pthread_cond_destroy(&vc_non_vuoto);
	pthread_mutex_destroy(&mutex_buffer);

	return (CU_get_error());
}
