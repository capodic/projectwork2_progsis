package com.capodic.ss_webclient;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;


public class WebViewClientImpl extends WebViewClient {

    private Activity activity = null;

    public WebViewClientImpl(Activity activity) {
        this.activity = activity;
    }

    @Override
    public boolean shouldOverrideUrlLoading(WebView webView, String url) {
        //Log.i("sswebclient", "shouldOverrideUrlLoading: "+url);
        Log.i("sswebclient", "shouldOverrideUrlLoading: "+url.replace("http://", "https://"));  // necessario perche' fa redirect su http:// ??
        webView.loadUrl(url.replace("http://", "https://"));
        return true;
    }

}